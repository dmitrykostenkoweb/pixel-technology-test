export default [
  {
    "Name": "Adanel",
    "Url": "http://lotr.wikia.com//wiki/Adanel",
    "Race": "Human"
  },
  {
    "Name": "Adrahil I",
    "Url": "http://lotr.wikia.com//wiki/Adrahil_I",
    "Race": "Human"
  },
  {
    "Name": "Adrahil II",
    "Url": "http://lotr.wikia.com//wiki/Adrahil_II",
    "Race": "Human"
  },
  {
    "Name": "Aegnor",
    "Url": "http://lotr.wikia.com//wiki/Aegnor",
    "Race": "Elf"
  },
  {
    "Name": "Aerin",
    "Url": "http://lotr.wikia.com//wiki/Aerin",
    "Race": "Human"
  },
  {
    "Name": "Aglahad",
    "Url": "http://lotr.wikia.com//wiki/Aglahad",
    "Race": "Human"
  },
  {
    "Name": "Ailinel",
    "Url": "http://lotr.wikia.com//wiki/Ailinel",
    "Race": "Human"
  },
  {
    "Name": "Aldamir",
    "Url": "http://lotr.wikia.com//wiki/Aldamir",
    "Race": "Human"
  },
  {
    "Name": "Aldor",
    "Url": "http://lotr.wikia.com//wiki/Aldor",
    "Race": "Human"
  },
  {
    "Name": "Algund",
    "Url": "http://lotr.wikia.com//wiki/Algund",
    "Race": "Human"
  },
  {
    "Name": "Almarian",
    "Url": "http://lotr.wikia.com//wiki/Almarian",
    "Race": "Human"
  },
  {
    "Name": "Almiel",
    "Url": "http://lotr.wikia.com//wiki/Almiel",
    "Race": "Human"
  },
  {
    "Name": "Alphros",
    "Url": "http://lotr.wikia.com//wiki/Alphros",
    "Race": "Human"
  },
  {
    "Name": "Amandil",
    "Url": "http://lotr.wikia.com//wiki/Amandil",
    "Race": "Human"
  },
  {
    "Name": "Amarië",
    "Url": "http://lotr.wikia.com//wiki/Amari%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Amdír",
    "Url": "http://lotr.wikia.com//wiki/Amd%C3%ADr",
    "Race": "Elf"
  },
  {
    "Name": "Amlaith",
    "Url": "http://lotr.wikia.com//wiki/Amlaith",
    "Race": "Human"
  },
  {
    "Name": "Amras",
    "Url": "http://lotr.wikia.com//wiki/Amras",
    "Race": "Elf"
  },
  {
    "Name": "Amrod",
    "Url": "http://lotr.wikia.com//wiki/Amrod",
    "Race": "Elf"
  },
  {
    "Name": "Amroth",
    "Url": "http://lotr.wikia.com//wiki/Amroth",
    "Race": "Elf"
  },
  {
    "Name": "Amrothos",
    "Url": "http://lotr.wikia.com//wiki/Amrothos",
    "Race": "Human"
  },
  {
    "Name": "Anairë",
    "Url": "http://lotr.wikia.com//wiki/Anair%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Anardil",
    "Url": "http://lotr.wikia.com//wiki/Anardil",
    "Race": "Human"
  },
  {
    "Name": "Anborn",
    "Url": "http://lotr.wikia.com//wiki/Anborn",
    "Race": "Human"
  },
  {
    "Name": "Andreth",
    "Url": "http://lotr.wikia.com//wiki/Andreth",
    "Race": "Human"
  },
  {
    "Name": "Andróg",
    "Url": "http://lotr.wikia.com//wiki/Andr%C3%B3g",
    "Race": "Human"
  },
  {
    "Name": "Angamaitë",
    "Url": "http://lotr.wikia.com//wiki/Angamait%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Angbor",
    "Url": "http://lotr.wikia.com//wiki/Angbor",
    "Race": "Human"
  },
  {
    "Name": "Angelimir",
    "Url": "http://lotr.wikia.com//wiki/Angelimir",
    "Race": "Human"
  },
  {
    "Name": "Angrod",
    "Url": "http://lotr.wikia.com//wiki/Angrod",
    "Race": "Elf"
  },
  {
    "Name": "Annael",
    "Url": "http://lotr.wikia.com//wiki/Annael",
    "Race": "Elf"
  },
  {
    "Name": "Anárion",
    "Url": "http://lotr.wikia.com//wiki/An%C3%A1rion",
    "Race": "Human"
  },
  {
    "Name": "Ar-Adûnakhôr",
    "Url": "http://lotr.wikia.com//wiki/Ar-Ad%C3%BBnakh%C3%B4r",
    "Race": "Human"
  },
  {
    "Name": "Ar-Gimilzôr",
    "Url": "http://lotr.wikia.com//wiki/Ar-Gimilz%C3%B4r",
    "Race": "Human"
  },
  {
    "Name": "Ar-Pharazôn",
    "Url": "http://lotr.wikia.com//wiki/Ar-Pharaz%C3%B4n",
    "Race": "Human"
  },
  {
    "Name": "Ar-Sakalthôr",
    "Url": "http://lotr.wikia.com//wiki/Ar-Sakalth%C3%B4r",
    "Race": "Human"
  },
  {
    "Name": "Ar-Zimrathôn",
    "Url": "http://lotr.wikia.com//wiki/Ar-Zimrath%C3%B4n",
    "Race": "Human"
  },
  {
    "Name": "Arador",
    "Url": "http://lotr.wikia.com//wiki/Arador",
    "Race": "Human"
  },
  {
    "Name": "Araglas",
    "Url": "http://lotr.wikia.com//wiki/Araglas",
    "Race": "Human"
  },
  {
    "Name": "Aragorn I",
    "Url": "http://lotr.wikia.com//wiki/Aragorn_I",
    "Race": "Human"
  },
  {
    "Name": "Aragorn II Elessar",
    "Url": "http://lotr.wikia.com//wiki/Aragorn_II_Elessar",
    "Race": "Human"
  },
  {
    "Name": "Aragost",
    "Url": "http://lotr.wikia.com//wiki/Aragost",
    "Race": "Human"
  },
  {
    "Name": "Arahad I",
    "Url": "http://lotr.wikia.com//wiki/Arahad_I",
    "Race": "Human"
  },
  {
    "Name": "Arahad II",
    "Url": "http://lotr.wikia.com//wiki/Arahad_II",
    "Race": "Human"
  },
  {
    "Name": "Arahael",
    "Url": "http://lotr.wikia.com//wiki/Arahael",
    "Race": "Human"
  },
  {
    "Name": "Aranarth",
    "Url": "http://lotr.wikia.com//wiki/Aranarth",
    "Race": "Human"
  },
  {
    "Name": "Arantar",
    "Url": "http://lotr.wikia.com//wiki/Arantar",
    "Race": "Human"
  },
  {
    "Name": "Aranuir",
    "Url": "http://lotr.wikia.com//wiki/Aranuir",
    "Race": "Human"
  },
  {
    "Name": "Aranwë",
    "Url": "http://lotr.wikia.com//wiki/Aranw%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Araphant",
    "Url": "http://lotr.wikia.com//wiki/Araphant",
    "Race": "Human"
  },
  {
    "Name": "Araphor",
    "Url": "http://lotr.wikia.com//wiki/Araphor",
    "Race": "Human"
  },
  {
    "Name": "Arassuil",
    "Url": "http://lotr.wikia.com//wiki/Arassuil",
    "Race": "Human"
  },
  {
    "Name": "Aratan",
    "Url": "http://lotr.wikia.com//wiki/Aratan",
    "Race": "Human"
  },
  {
    "Name": "Arathorn I",
    "Url": "http://lotr.wikia.com//wiki/Arathorn_I",
    "Race": "Human"
  },
  {
    "Name": "Arathorn II",
    "Url": "http://lotr.wikia.com//wiki/Arathorn_II",
    "Race": "Human"
  },
  {
    "Name": "Araval",
    "Url": "http://lotr.wikia.com//wiki/Araval",
    "Race": "Human"
  },
  {
    "Name": "Aravir",
    "Url": "http://lotr.wikia.com//wiki/Aravir",
    "Race": "Human"
  },
  {
    "Name": "Aravorn",
    "Url": "http://lotr.wikia.com//wiki/Aravorn",
    "Race": "Human"
  },
  {
    "Name": "Arciryas",
    "Url": "http://lotr.wikia.com//wiki/Arciryas",
    "Race": "Human"
  },
  {
    "Name": "Ardamir (son of Axantur)",
    "Url": "http://lotr.wikia.com//wiki/Ardamir_(son_of_Axantur)",
    "Race": "Human"
  },
  {
    "Name": "Aredhel",
    "Url": "http://lotr.wikia.com//wiki/Aredhel",
    "Race": "Elf"
  },
  {
    "Name": "Argeleb I",
    "Url": "http://lotr.wikia.com//wiki/Argeleb_I",
    "Race": "Human"
  },
  {
    "Name": "Argeleb II",
    "Url": "http://lotr.wikia.com//wiki/Argeleb_II",
    "Race": "Human"
  },
  {
    "Name": "Argon",
    "Url": "http://lotr.wikia.com//wiki/Argon",
    "Race": "Elf"
  },
  {
    "Name": "Argonui",
    "Url": "http://lotr.wikia.com//wiki/Argonui",
    "Race": "Human"
  },
  {
    "Name": "Arminas",
    "Url": "http://lotr.wikia.com//wiki/Arminas",
    "Race": "Elf"
  },
  {
    "Name": "Arthad",
    "Url": "http://lotr.wikia.com//wiki/Arthad",
    "Race": "Human"
  },
  {
    "Name": "Arvedui",
    "Url": "http://lotr.wikia.com//wiki/Arvedui",
    "Race": "Human"
  },
  {
    "Name": "Arvegil",
    "Url": "http://lotr.wikia.com//wiki/Arvegil",
    "Race": "Human"
  },
  {
    "Name": "Arveleg I",
    "Url": "http://lotr.wikia.com//wiki/Arveleg_I",
    "Race": "Human"
  },
  {
    "Name": "Arveleg II",
    "Url": "http://lotr.wikia.com//wiki/Arveleg_II",
    "Race": "Human"
  },
  {
    "Name": "Arwen",
    "Url": "http://lotr.wikia.com//wiki/Arwen",
    "Race": "Elf"
  },
  {
    "Name": "Atanalcar",
    "Url": "http://lotr.wikia.com//wiki/Atanalcar",
    "Race": "Human"
  },
  {
    "Name": "Atanatar I",
    "Url": "http://lotr.wikia.com//wiki/Atanatar_I",
    "Race": "Human"
  },
  {
    "Name": "Atanatar II",
    "Url": "http://lotr.wikia.com//wiki/Atanatar_II",
    "Race": "Human"
  },
  {
    "Name": "Aulendil (Vardamir's son)",
    "Url": "http://lotr.wikia.com//wiki/Aulendil_(Vardamir%27s_son)",
    "Race": "Human"
  },
  {
    "Name": "Axantur",
    "Url": "http://lotr.wikia.com//wiki/Axantur",
    "Race": "Human"
  },
  {
    "Name": "Azaghâl",
    "Url": "http://lotr.wikia.com//wiki/Azagh%C3%A2l",
    "Race": "Dwarf"
  },
  {
    "Name": "Angelica Baggins",
    "Url": "http://lotr.wikia.com//wiki/Angelica_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Balbo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Balbo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Belladonna (Took) Baggins",
    "Url": "http://lotr.wikia.com//wiki/Belladonna_(Took)_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Berylla (Boffin) Baggins",
    "Url": "http://lotr.wikia.com//wiki/Berylla_(Boffin)_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Bungo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Bungo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Drogo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Drogo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Dudo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Dudo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Fosco Baggins",
    "Url": "http://lotr.wikia.com//wiki/Fosco_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Frodo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Frodo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Laura (Grubb) Baggins",
    "Url": "http://lotr.wikia.com//wiki/Laura_(Grubb)_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Longo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Longo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Mungo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Mungo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Peony (Baggins) Burrows",
    "Url": "http://lotr.wikia.com//wiki/Peony_(Baggins)_Burrows",
    "Race": "Hobbit"
  },
  {
    "Name": "Ponto Baggins",
    "Url": "http://lotr.wikia.com//wiki/Ponto_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Ponto Baggins II",
    "Url": "http://lotr.wikia.com//wiki/Ponto_Baggins_II",
    "Race": "Hobbit"
  },
  {
    "Name": "Porto Baggins",
    "Url": "http://lotr.wikia.com//wiki/Porto_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Bain",
    "Url": "http://lotr.wikia.com//wiki/Bain",
    "Race": "Human"
  },
  {
    "Name": "Balin",
    "Url": "http://lotr.wikia.com//wiki/Balin",
    "Race": "Dwarf"
  },
  {
    "Name": "Baragund",
    "Url": "http://lotr.wikia.com//wiki/Baragund",
    "Race": "Human"
  },
  {
    "Name": "Barahir",
    "Url": "http://lotr.wikia.com//wiki/Barahir",
    "Race": "Human"
  },
  {
    "Name": "Barahir (Steward)",
    "Url": "http://lotr.wikia.com//wiki/Barahir_(Steward)",
    "Race": "Human"
  },
  {
    "Name": "Baran",
    "Url": "http://lotr.wikia.com//wiki/Baran",
    "Race": "Human"
  },
  {
    "Name": "Baranor",
    "Url": "http://lotr.wikia.com//wiki/Baranor",
    "Race": "Human"
  },
  {
    "Name": "Baranor (Gondor)",
    "Url": "http://lotr.wikia.com//wiki/Baranor_(Gondor)",
    "Race": "Human"
  },
  {
    "Name": "Bard",
    "Url": "http://lotr.wikia.com//wiki/Bard",
    "Race": "Human"
  },
  {
    "Name": "Bard II",
    "Url": "http://lotr.wikia.com//wiki/Bard_II",
    "Race": "Human"
  },
  {
    "Name": "Beldir",
    "Url": "http://lotr.wikia.com//wiki/Beldir",
    "Race": "Human"
  },
  {
    "Name": "Beldis",
    "Url": "http://lotr.wikia.com//wiki/Beldis",
    "Race": "Human"
  },
  {
    "Name": "Belecthor I",
    "Url": "http://lotr.wikia.com//wiki/Belecthor_I",
    "Race": "Human"
  },
  {
    "Name": "Belecthor II",
    "Url": "http://lotr.wikia.com//wiki/Belecthor_II",
    "Race": "Human"
  },
  {
    "Name": "Beleg of Arnor",
    "Url": "http://lotr.wikia.com//wiki/Beleg_of_Arnor",
    "Race": "Human"
  },
  {
    "Name": "Belegorn",
    "Url": "http://lotr.wikia.com//wiki/Belegorn",
    "Race": "Human"
  },
  {
    "Name": "Belegund",
    "Url": "http://lotr.wikia.com//wiki/Belegund",
    "Race": "Human"
  },
  {
    "Name": "Belemir",
    "Url": "http://lotr.wikia.com//wiki/Belemir",
    "Race": "Human"
  },
  {
    "Name": "Belen",
    "Url": "http://lotr.wikia.com//wiki/Belen",
    "Race": "Human"
  },
  {
    "Name": "Beorn",
    "Url": "http://lotr.wikia.com//wiki/Beorn",
    "Race": "Human"
  },
  {
    "Name": "Bereg",
    "Url": "http://lotr.wikia.com//wiki/Bereg",
    "Race": "Human"
  },
  {
    "Name": "Beregond",
    "Url": "http://lotr.wikia.com//wiki/Beregond",
    "Race": "Human"
  },
  {
    "Name": "Beregond (Captain)",
    "Url": "http://lotr.wikia.com//wiki/Beregond_(Captain)",
    "Race": "Human"
  },
  {
    "Name": "Berelach",
    "Url": "http://lotr.wikia.com//wiki/Berelach",
    "Race": "Human"
  },
  {
    "Name": "Beren",
    "Url": "http://lotr.wikia.com//wiki/Beren",
    "Race": "Human"
  },
  {
    "Name": "Beren (Belemir's son)",
    "Url": "http://lotr.wikia.com//wiki/Beren_(Belemir%27s_son)",
    "Race": "Human"
  },
  {
    "Name": "Beren (Steward)",
    "Url": "http://lotr.wikia.com//wiki/Beren_(Steward)",
    "Race": "Human"
  },
  {
    "Name": "Bergil",
    "Url": "http://lotr.wikia.com//wiki/Bergil",
    "Race": "Human"
  },
  {
    "Name": "Bifur",
    "Url": "http://lotr.wikia.com//wiki/Bifur",
    "Race": "Dwarf"
  },
  {
    "Name": "Bilbo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Bilbo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Black Serpent",
    "Url": "http://lotr.wikia.com//wiki/Black_Serpent",
    "Race": "Human"
  },
  {
    "Name": "Bladorthin",
    "Url": "http://lotr.wikia.com//wiki/Bladorthin",
    "Race": "Human"
  },
  {
    "Name": "Blanco",
    "Url": "http://lotr.wikia.com//wiki/Blanco",
    "Race": "Hobbit"
  },
  {
    "Name": "Bob",
    "Url": "http://lotr.wikia.com//wiki/Bob",
    "Race": "Hobbit"
  },
  {
    "Name": "Donnamira (Took) Boffin",
    "Url": "http://lotr.wikia.com//wiki/Donnamira_(Took)_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Basso Boffin",
    "Url": "http://lotr.wikia.com//wiki/Basso_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Bosco Boffin",
    "Url": "http://lotr.wikia.com//wiki/Bosco_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Buffo Boffin",
    "Url": "http://lotr.wikia.com//wiki/Buffo_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Daisy (Baggins) Boffin",
    "Url": "http://lotr.wikia.com//wiki/Daisy_(Baggins)_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Druda Burrows Boffin",
    "Url": "http://lotr.wikia.com//wiki/Druda_Burrows_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Folco Boffin",
    "Url": "http://lotr.wikia.com//wiki/Folco_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Gerda (Boffin) Bolger",
    "Url": "http://lotr.wikia.com//wiki/Gerda_(Boffin)_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Griffo Boffin",
    "Url": "http://lotr.wikia.com//wiki/Griffo_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Hugo Boffin",
    "Url": "http://lotr.wikia.com//wiki/Hugo_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Ivy (Goodenough) Boffin",
    "Url": "http://lotr.wikia.com//wiki/Ivy_(Goodenough)_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Jago Boffin",
    "Url": "http://lotr.wikia.com//wiki/Jago_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Otto Boffin",
    "Url": "http://lotr.wikia.com//wiki/Otto_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Rollo Boffin",
    "Url": "http://lotr.wikia.com//wiki/Rollo_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Tosto Boffin",
    "Url": "http://lotr.wikia.com//wiki/Tosto_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Vigo Boffin",
    "Url": "http://lotr.wikia.com//wiki/Vigo_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Bofur",
    "Url": "http://lotr.wikia.com//wiki/Bofur",
    "Race": "Dwarf"
  },
  {
    "Name": "Filibert Bolger",
    "Url": "http://lotr.wikia.com//wiki/Filibert_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Fredegar Bolger",
    "Url": "http://lotr.wikia.com//wiki/Fredegar_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Jessamine (Boffin) Bolger",
    "Url": "http://lotr.wikia.com//wiki/Jessamine_(Boffin)_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Odovacar Bolger",
    "Url": "http://lotr.wikia.com//wiki/Odovacar_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Rosamunda (Took) Bolger",
    "Url": "http://lotr.wikia.com//wiki/Rosamunda_(Took)_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Wilibald Bolger",
    "Url": "http://lotr.wikia.com//wiki/Wilibald_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Bombur",
    "Url": "http://lotr.wikia.com//wiki/Bombur",
    "Race": "Dwarf"
  },
  {
    "Name": "Borin",
    "Url": "http://lotr.wikia.com//wiki/Borin",
    "Race": "Dwarf"
  },
  {
    "Name": "Borlach",
    "Url": "http://lotr.wikia.com//wiki/Borlach",
    "Race": "Human"
  },
  {
    "Name": "Borlad",
    "Url": "http://lotr.wikia.com//wiki/Borlad",
    "Race": "Human"
  },
  {
    "Name": "Borlas",
    "Url": "http://lotr.wikia.com//wiki/Borlas",
    "Race": "Human"
  },
  {
    "Name": "Boromir",
    "Url": "http://lotr.wikia.com//wiki/Boromir",
    "Race": "Human"
  },
  {
    "Name": "Boromir (House of Bëor)",
    "Url": "http://lotr.wikia.com//wiki/Boromir_(House_of_B%C3%ABor)",
    "Race": "Human"
  },
  {
    "Name": "Boromir (Steward)",
    "Url": "http://lotr.wikia.com//wiki/Boromir_(Steward)",
    "Race": "Human"
  },
  {
    "Name": "Boron",
    "Url": "http://lotr.wikia.com//wiki/Boron",
    "Race": "Human"
  },
  {
    "Name": "Borondir",
    "Url": "http://lotr.wikia.com//wiki/Borondir",
    "Race": "Human"
  },
  {
    "Name": "Borthand",
    "Url": "http://lotr.wikia.com//wiki/Borthand",
    "Race": "Human"
  },
  {
    "Name": "Blanco Bracegirdle",
    "Url": "http://lotr.wikia.com//wiki/Blanco_Bracegirdle",
    "Race": "Hobbit"
  },
  {
    "Name": "Bruno Bracegirdle",
    "Url": "http://lotr.wikia.com//wiki/Bruno_Bracegirdle",
    "Race": "Hobbit"
  },
  {
    "Name": "Primrose Bracegirdle",
    "Url": "http://lotr.wikia.com//wiki/Primrose_Bracegirdle",
    "Race": "Hobbit"
  },
  {
    "Name": "Brand",
    "Url": "http://lotr.wikia.com//wiki/Brand",
    "Race": "Human"
  },
  {
    "Name": "Brandir",
    "Url": "http://lotr.wikia.com//wiki/Brandir",
    "Race": "Human"
  },
  {
    "Name": "Adaldrida (Bolger) Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Adaldrida_(Bolger)_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Amaranth Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Amaranth_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Celandine Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Celandine_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Esmeralda Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Esmeralda_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Estella (Bolger) Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Estella_(Bolger)_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Hilda Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Hilda_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Madoc Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Madoc_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Melilot Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Melilot_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Mentha Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Mentha_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Meriadoc Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Meriadoc_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Mirabella (Took) Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Mirabella_(Took)_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Primula (Brandybuck) Baggins",
    "Url": "http://lotr.wikia.com//wiki/Primula_(Brandybuck)_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Seredic Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Seredic_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Brego",
    "Url": "http://lotr.wikia.com//wiki/Brego",
    "Race": "Human"
  },
  {
    "Name": "Bregolas",
    "Url": "http://lotr.wikia.com//wiki/Bregolas",
    "Race": "Human"
  },
  {
    "Name": "Bregor",
    "Url": "http://lotr.wikia.com//wiki/Bregor",
    "Race": "Human"
  },
  {
    "Name": "Sapphira (Brockhouse) Boffin",
    "Url": "http://lotr.wikia.com//wiki/Sapphira_(Brockhouse)_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Bucca of the Marish",
    "Url": "http://lotr.wikia.com//wiki/Bucca_of_the_Marish",
    "Race": "Hobbit"
  },
  {
    "Name": "Asphodel (Brandybuck) Burrows",
    "Url": "http://lotr.wikia.com//wiki/Asphodel_(Brandybuck)_Burrows",
    "Race": "Hobbit"
  },
  {
    "Name": "Milo Burrows",
    "Url": "http://lotr.wikia.com//wiki/Milo_Burrows",
    "Race": "Hobbit"
  },
  {
    "Name": "Minto Burrows",
    "Url": "http://lotr.wikia.com//wiki/Minto_Burrows",
    "Race": "Hobbit"
  },
  {
    "Name": "Bëor",
    "Url": "http://lotr.wikia.com//wiki/B%C3%ABor",
    "Race": "Human"
  },
  {
    "Name": "Bór",
    "Url": "http://lotr.wikia.com//wiki/B%C3%B3r",
    "Race": "Human"
  },
  {
    "Name": "Calimehtar",
    "Url": "http://lotr.wikia.com//wiki/Calimehtar",
    "Race": "Human"
  },
  {
    "Name": "Caliondo",
    "Url": "http://lotr.wikia.com//wiki/Caliondo",
    "Race": "Human"
  },
  {
    "Name": "Calmacil",
    "Url": "http://lotr.wikia.com//wiki/Calmacil",
    "Race": "Human"
  },
  {
    "Name": "Caranthir",
    "Url": "http://lotr.wikia.com//wiki/Caranthir",
    "Race": "Elf"
  },
  {
    "Name": "Castamir the Usurper",
    "Url": "http://lotr.wikia.com//wiki/Castamir_the_Usurper",
    "Race": "Human"
  },
  {
    "Name": "Celeborn",
    "Url": "http://lotr.wikia.com//wiki/Celeborn",
    "Race": "Elf"
  },
  {
    "Name": "Celebrimbor",
    "Url": "http://lotr.wikia.com//wiki/Celebrimbor",
    "Race": "Elf"
  },
  {
    "Name": "Celebrindor",
    "Url": "http://lotr.wikia.com//wiki/Celebrindor",
    "Race": "Human"
  },
  {
    "Name": "Celebrían",
    "Url": "http://lotr.wikia.com//wiki/Celebr%C3%ADan",
    "Race": "Elf"
  },
  {
    "Name": "Celegorm",
    "Url": "http://lotr.wikia.com//wiki/Celegorm",
    "Race": "Elf"
  },
  {
    "Name": "Celepharn",
    "Url": "http://lotr.wikia.com//wiki/Celepharn",
    "Race": "Human"
  },
  {
    "Name": "Cemendur",
    "Url": "http://lotr.wikia.com//wiki/Cemendur",
    "Race": "Human"
  },
  {
    "Name": "Cemendur (son of Axantur)",
    "Url": "http://lotr.wikia.com//wiki/Cemendur_(son_of_Axantur)",
    "Race": "Human"
  },
  {
    "Name": "Ceorl",
    "Url": "http://lotr.wikia.com//wiki/Ceorl",
    "Race": "Human"
  },
  {
    "Name": "Falco Chubb-Baggins",
    "Url": "http://lotr.wikia.com//wiki/Falco_Chubb-Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Cirion",
    "Url": "http://lotr.wikia.com//wiki/Cirion",
    "Race": "Human"
  },
  {
    "Name": "Ciryandil",
    "Url": "http://lotr.wikia.com//wiki/Ciryandil",
    "Race": "Human"
  },
  {
    "Name": "Ciryatur",
    "Url": "http://lotr.wikia.com//wiki/Ciryatur",
    "Race": "Human"
  },
  {
    "Name": "Ciryon",
    "Url": "http://lotr.wikia.com//wiki/Ciryon",
    "Race": "Human"
  },
  {
    "Name": "Bowman Cotton",
    "Url": "http://lotr.wikia.com//wiki/Bowman_Cotton",
    "Race": "Hobbit"
  },
  {
    "Name": "Lily Cotton",
    "Url": "http://lotr.wikia.com//wiki/Lily_Cotton",
    "Race": "Hobbit"
  },
  {
    "Name": "Marigold (Gamgee) Cotton",
    "Url": "http://lotr.wikia.com//wiki/Marigold_(Gamgee)_Cotton",
    "Race": "Hobbit"
  },
  {
    "Name": "Rosie Cotton",
    "Url": "http://lotr.wikia.com//wiki/Rosie_Cotton",
    "Race": "Hobbit"
  },
  {
    "Name": "Tolman Cotton",
    "Url": "http://lotr.wikia.com//wiki/Tolman_Cotton",
    "Race": "Hobbit"
  },
  {
    "Name": "Curufin",
    "Url": "http://lotr.wikia.com//wiki/Curufin",
    "Race": "Elf"
  },
  {
    "Name": "Círdan",
    "Url": "http://lotr.wikia.com//wiki/C%C3%ADrdan",
    "Race": "Elf"
  },
  {
    "Name": "Dairuin",
    "Url": "http://lotr.wikia.com//wiki/Dairuin",
    "Race": "Human"
  },
  {
    "Name": "Damrod",
    "Url": "http://lotr.wikia.com//wiki/Damrod",
    "Race": "Human"
  },
  {
    "Name": "Denethor (First Age)",
    "Url": "http://lotr.wikia.com//wiki/Denethor_(First_Age)",
    "Race": "Elf"
  },
  {
    "Name": "Denethor I",
    "Url": "http://lotr.wikia.com//wiki/Denethor_I",
    "Race": "Human"
  },
  {
    "Name": "Denethor II",
    "Url": "http://lotr.wikia.com//wiki/Denethor_II",
    "Race": "Human"
  },
  {
    "Name": "Derufin",
    "Url": "http://lotr.wikia.com//wiki/Derufin",
    "Race": "Human"
  },
  {
    "Name": "Dervorin",
    "Url": "http://lotr.wikia.com//wiki/Dervorin",
    "Race": "Human"
  },
  {
    "Name": "Diamond Took",
    "Url": "http://lotr.wikia.com//wiki/Diamond_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Dinodas Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Dinodas_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Dior (Steward)",
    "Url": "http://lotr.wikia.com//wiki/Dior_(Steward)",
    "Race": "Human"
  },
  {
    "Name": "Dodinas Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Dodinas_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Dori",
    "Url": "http://lotr.wikia.com//wiki/Dori",
    "Race": "Dwarf"
  },
  {
    "Name": "Dorlas",
    "Url": "http://lotr.wikia.com//wiki/Dorlas",
    "Race": "Human"
  },
  {
    "Name": "Duilin",
    "Url": "http://lotr.wikia.com//wiki/Duilin",
    "Race": "Human"
  },
  {
    "Name": "Duinhir",
    "Url": "http://lotr.wikia.com//wiki/Duinhir",
    "Race": "Human"
  },
  {
    "Name": "Durin VII",
    "Url": "http://lotr.wikia.com//wiki/Durin_VII",
    "Race": "Dwarf"
  },
  {
    "Name": "Dwalin",
    "Url": "http://lotr.wikia.com//wiki/Dwalin",
    "Race": "Dwarf"
  },
  {
    "Name": "Dáin I",
    "Url": "http://lotr.wikia.com//wiki/D%C3%A1in_I",
    "Race": "Dwarf"
  },
  {
    "Name": "Dáin II Ironfoot",
    "Url": "http://lotr.wikia.com//wiki/D%C3%A1in_II_Ironfoot",
    "Race": "Dwarf"
  },
  {
    "Name": "Déagol",
    "Url": "http://lotr.wikia.com//wiki/D%C3%A9agol",
    "Race": "Hobbit"
  },
  {
    "Name": "Déor",
    "Url": "http://lotr.wikia.com//wiki/D%C3%A9or",
    "Race": "Human"
  },
  {
    "Name": "Déorwine",
    "Url": "http://lotr.wikia.com//wiki/D%C3%A9orwine",
    "Race": "Human"
  },
  {
    "Name": "Dírhael",
    "Url": "http://lotr.wikia.com//wiki/D%C3%ADrhael",
    "Race": "Human"
  },
  {
    "Name": "Dírhavel",
    "Url": "http://lotr.wikia.com//wiki/D%C3%ADrhavel",
    "Race": "Human"
  },
  {
    "Name": "Dís",
    "Url": "http://lotr.wikia.com//wiki/D%C3%ADs",
    "Race": "Dwarf"
  },
  {
    "Name": "Dúnhere",
    "Url": "http://lotr.wikia.com//wiki/D%C3%BAnhere",
    "Race": "Human"
  },
  {
    "Name": "Ecthelion I",
    "Url": "http://lotr.wikia.com//wiki/Ecthelion_I",
    "Race": "Human"
  },
  {
    "Name": "Ecthelion II",
    "Url": "http://lotr.wikia.com//wiki/Ecthelion_II",
    "Race": "Human"
  },
  {
    "Name": "Edrahil",
    "Url": "http://lotr.wikia.com//wiki/Edrahil",
    "Race": "Elf"
  },
  {
    "Name": "Egalmoth",
    "Url": "http://lotr.wikia.com//wiki/Egalmoth",
    "Race": "Human"
  },
  {
    "Name": "Eglantine (Banks) Took",
    "Url": "http://lotr.wikia.com//wiki/Eglantine_(Banks)_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Eilinel",
    "Url": "http://lotr.wikia.com//wiki/Eilinel",
    "Race": "Human"
  },
  {
    "Name": "Elatan",
    "Url": "http://lotr.wikia.com//wiki/Elatan",
    "Race": "Human"
  },
  {
    "Name": "Elboron",
    "Url": "http://lotr.wikia.com//wiki/Elboron",
    "Race": "Human"
  },
  {
    "Name": "Eldacar (King of Arnor)",
    "Url": "http://lotr.wikia.com//wiki/Eldacar_(King_of_Arnor)",
    "Race": "Human"
  },
  {
    "Name": "Eldacar (King of Gondor)",
    "Url": "http://lotr.wikia.com//wiki/Eldacar_(King_of_Gondor)",
    "Race": "Human"
  },
  {
    "Name": "Eldalótë",
    "Url": "http://lotr.wikia.com//wiki/Eldal%C3%B3t%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Eldarion",
    "Url": "http://lotr.wikia.com//wiki/Eldarion",
    "Race": "Human"
  },
  {
    "Name": "Elemmírë (elf)",
    "Url": "http://lotr.wikia.com//wiki/Elemm%C3%ADr%C3%AB_(elf)",
    "Race": "Elf"
  },
  {
    "Name": "Elendil",
    "Url": "http://lotr.wikia.com//wiki/Elendil",
    "Race": "Human"
  },
  {
    "Name": "Elendur",
    "Url": "http://lotr.wikia.com//wiki/Elendur",
    "Race": "Human"
  },
  {
    "Name": "Elendur of Arnor",
    "Url": "http://lotr.wikia.com//wiki/Elendur_of_Arnor",
    "Race": "Human"
  },
  {
    "Name": "Elenwë",
    "Url": "http://lotr.wikia.com//wiki/Elenw%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Elfhelm",
    "Url": "http://lotr.wikia.com//wiki/Elfhelm",
    "Race": "Human"
  },
  {
    "Name": "Elfhild",
    "Url": "http://lotr.wikia.com//wiki/Elfhild",
    "Race": "Human"
  },
  {
    "Name": "Elfwine",
    "Url": "http://lotr.wikia.com//wiki/Elfwine",
    "Race": "Human"
  },
  {
    "Name": "Elladan and Elrohir",
    "Url": "http://lotr.wikia.com//wiki/Elladan_and_Elrohir",
    "Race": "Elf"
  },
  {
    "Name": "Elphir",
    "Url": "http://lotr.wikia.com//wiki/Elphir",
    "Race": "Human"
  },
  {
    "Name": "Elrond",
    "Url": "http://lotr.wikia.com//wiki/Elrond",
    "Race": "Elf"
  },
  {
    "Name": "Emeldir",
    "Url": "http://lotr.wikia.com//wiki/Emeldir",
    "Race": "Human"
  },
  {
    "Name": "Enel",
    "Url": "http://lotr.wikia.com//wiki/Enel",
    "Race": "Elf"
  },
  {
    "Name": "Enelyë",
    "Url": "http://lotr.wikia.com//wiki/Enely%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Enerdhil",
    "Url": "http://lotr.wikia.com//wiki/Enerdhil",
    "Race": "Elf"
  },
  {
    "Name": "Éomer",
    "Url": "http://lotr.wikia.com//wiki/%C3%89omer",
    "Race": "Human"
  },
  {
    "Name": "Eorl the Young",
    "Url": "http://lotr.wikia.com//wiki/Eorl_the_Young",
    "Race": "Human"
  },
  {
    "Name": "Éowyn",
    "Url": "http://lotr.wikia.com//wiki/%C3%89owyn",
    "Race": "Human"
  },
  {
    "Name": "Eradan",
    "Url": "http://lotr.wikia.com//wiki/Eradan",
    "Race": "Human"
  },
  {
    "Name": "Erchirion",
    "Url": "http://lotr.wikia.com//wiki/Erchirion",
    "Race": "Human"
  },
  {
    "Name": "Erellont",
    "Url": "http://lotr.wikia.com//wiki/Erellont",
    "Race": "Elf"
  },
  {
    "Name": "Erendis",
    "Url": "http://lotr.wikia.com//wiki/Erendis",
    "Race": "Human"
  },
  {
    "Name": "Erestor",
    "Url": "http://lotr.wikia.com//wiki/Erestor",
    "Race": "Elf"
  },
  {
    "Name": "Erkenbrand",
    "Url": "http://lotr.wikia.com//wiki/Erkenbrand",
    "Race": "Human"
  },
  {
    "Name": "Estelmo",
    "Url": "http://lotr.wikia.com//wiki/Estelmo",
    "Race": "Human"
  },
  {
    "Name": "Eärendil of Gondor",
    "Url": "http://lotr.wikia.com//wiki/E%C3%A4rendil_of_Gondor",
    "Race": "Human"
  },
  {
    "Name": "Eärendur (Lord of Andúnië)",
    "Url": "http://lotr.wikia.com//wiki/E%C3%A4rendur_(Lord_of_And%C3%BAni%C3%AB)",
    "Race": "Human"
  },
  {
    "Name": "Eärendur of Arnor",
    "Url": "http://lotr.wikia.com//wiki/E%C3%A4rendur_of_Arnor",
    "Race": "Human"
  },
  {
    "Name": "Eärendur of Númenor",
    "Url": "http://lotr.wikia.com//wiki/E%C3%A4rendur_of_N%C3%BAmenor",
    "Race": "Human"
  },
  {
    "Name": "Eärnil I",
    "Url": "http://lotr.wikia.com//wiki/E%C3%A4rnil_I",
    "Race": "Human"
  },
  {
    "Name": "Eärnil II",
    "Url": "http://lotr.wikia.com//wiki/E%C3%A4rnil_II",
    "Race": "Human"
  },
  {
    "Name": "Eärnur",
    "Url": "http://lotr.wikia.com//wiki/E%C3%A4rnur",
    "Race": "Human"
  },
  {
    "Name": "Eärwen",
    "Url": "http://lotr.wikia.com//wiki/E%C3%A4rwen",
    "Race": "Elf"
  },
  {
    "Name": "Eöl",
    "Url": "http://lotr.wikia.com//wiki/E%C3%B6l",
    "Race": "Elf"
  },
  {
    "Name": "Faramir",
    "Url": "http://lotr.wikia.com//wiki/Faramir",
    "Race": "Human"
  },
  {
    "Name": "Faramir (son of Ondoher)",
    "Url": "http://lotr.wikia.com//wiki/Faramir_(son_of_Ondoher)",
    "Race": "Human"
  },
  {
    "Name": "Farin",
    "Url": "http://lotr.wikia.com//wiki/Farin",
    "Race": "Dwarf"
  },
  {
    "Name": "Fastolph Bolger",
    "Url": "http://lotr.wikia.com//wiki/Fastolph_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Fastred",
    "Url": "http://lotr.wikia.com//wiki/Fastred",
    "Race": "Human"
  },
  {
    "Name": "Fastred (Pelennor Fields)",
    "Url": "http://lotr.wikia.com//wiki/Fastred_(Pelennor_Fields)",
    "Race": "Human"
  },
  {
    "Name": "Fengel",
    "Url": "http://lotr.wikia.com//wiki/Fengel",
    "Race": "Human"
  },
  {
    "Name": "Ferumbras Took II",
    "Url": "http://lotr.wikia.com//wiki/Ferumbras_Took_II",
    "Race": "Hobbit"
  },
  {
    "Name": "Finarfin",
    "Url": "http://lotr.wikia.com//wiki/Finarfin",
    "Race": "Elf"
  },
  {
    "Name": "Findegil",
    "Url": "http://lotr.wikia.com//wiki/Findegil",
    "Race": "Human"
  },
  {
    "Name": "Findis",
    "Url": "http://lotr.wikia.com//wiki/Findis",
    "Race": "Elf"
  },
  {
    "Name": "Finduilas",
    "Url": "http://lotr.wikia.com//wiki/Finduilas",
    "Race": "Elf"
  },
  {
    "Name": "Finduilas of Dol Amroth",
    "Url": "http://lotr.wikia.com//wiki/Finduilas_of_Dol_Amroth",
    "Race": "Human"
  },
  {
    "Name": "Fingolfin",
    "Url": "http://lotr.wikia.com//wiki/Fingolfin",
    "Race": "Elf"
  },
  {
    "Name": "Fingon",
    "Url": "http://lotr.wikia.com//wiki/Fingon",
    "Race": "Elf"
  },
  {
    "Name": "Finrod",
    "Url": "http://lotr.wikia.com//wiki/Finrod",
    "Race": "Elf"
  },
  {
    "Name": "Finwë",
    "Url": "http://lotr.wikia.com//wiki/Finw%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Flói",
    "Url": "http://lotr.wikia.com//wiki/Fl%C3%B3i",
    "Race": "Dwarf"
  },
  {
    "Name": "Folca",
    "Url": "http://lotr.wikia.com//wiki/Folca",
    "Race": "Human"
  },
  {
    "Name": "Folcred",
    "Url": "http://lotr.wikia.com//wiki/Folcred",
    "Race": "Human"
  },
  {
    "Name": "Folcwine",
    "Url": "http://lotr.wikia.com//wiki/Folcwine",
    "Race": "Human"
  },
  {
    "Name": "Forlong",
    "Url": "http://lotr.wikia.com//wiki/Forlong",
    "Race": "Human"
  },
  {
    "Name": "Forthwini",
    "Url": "http://lotr.wikia.com//wiki/Forthwini",
    "Race": "Human"
  },
  {
    "Name": "Fortinbras Took I",
    "Url": "http://lotr.wikia.com//wiki/Fortinbras_Took_I",
    "Race": "Hobbit"
  },
  {
    "Name": "Forweg",
    "Url": "http://lotr.wikia.com//wiki/Forweg",
    "Race": "Human"
  },
  {
    "Name": "Fram",
    "Url": "http://lotr.wikia.com//wiki/Fram",
    "Race": "Human"
  },
  {
    "Name": "Freca",
    "Url": "http://lotr.wikia.com//wiki/Freca",
    "Race": "Human"
  },
  {
    "Name": "Frerin",
    "Url": "http://lotr.wikia.com//wiki/Frerin",
    "Race": "Dwarf"
  },
  {
    "Name": "Frumgar",
    "Url": "http://lotr.wikia.com//wiki/Frumgar",
    "Race": "Human"
  },
  {
    "Name": "Frár",
    "Url": "http://lotr.wikia.com//wiki/Fr%C3%A1r",
    "Race": "Dwarf"
  },
  {
    "Name": "Fréa",
    "Url": "http://lotr.wikia.com//wiki/Fr%C3%A9a",
    "Race": "Human"
  },
  {
    "Name": "Fréaláf Hildeson",
    "Url": "http://lotr.wikia.com//wiki/Fr%C3%A9al%C3%A1f_Hildeson",
    "Race": "Human"
  },
  {
    "Name": "Fréawine",
    "Url": "http://lotr.wikia.com//wiki/Fr%C3%A9awine",
    "Race": "Human"
  },
  {
    "Name": "Frór",
    "Url": "http://lotr.wikia.com//wiki/Fr%C3%B3r",
    "Race": "Dwarf"
  },
  {
    "Name": "Fundin",
    "Url": "http://lotr.wikia.com//wiki/Fundin",
    "Race": "Dwarf"
  },
  {
    "Name": "Fëanor",
    "Url": "http://lotr.wikia.com//wiki/F%C3%ABanor",
    "Race": "Elf"
  },
  {
    "Name": "Fíli and Kíli",
    "Url": "http://lotr.wikia.com//wiki/F%C3%ADli_and_K%C3%ADli",
    "Race": "Dwarf"
  },
  {
    "Name": "Fíriel",
    "Url": "http://lotr.wikia.com//wiki/F%C3%ADriel",
    "Race": "Human"
  },
  {
    "Name": "Galadriel",
    "Url": "http://lotr.wikia.com//wiki/Galadriel",
    "Race": "Elf"
  },
  {
    "Name": "Galar",
    "Url": "http://lotr.wikia.com//wiki/Galar",
    "Race": "Dwarf"
  },
  {
    "Name": "Galdor",
    "Url": "http://lotr.wikia.com//wiki/Galdor",
    "Race": "Human"
  },
  {
    "Name": "Galdor of the Havens",
    "Url": "http://lotr.wikia.com//wiki/Galdor_of_the_Havens",
    "Race": "Elf"
  },
  {
    "Name": "Galion",
    "Url": "http://lotr.wikia.com//wiki/Galion",
    "Race": "Elf"
  },
  {
    "Name": "Daisy Gamgee I",
    "Url": "http://lotr.wikia.com//wiki/Daisy_Gamgee_I",
    "Race": "Hobbit"
  },
  {
    "Name": "Frodo Gardner",
    "Url": "http://lotr.wikia.com//wiki/Frodo_Gardner",
    "Race": "Hobbit"
  },
  {
    "Name": "Halfred Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Halfred_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Hamfast Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Hamfast_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Hamson Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Hamson_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "May Gamgee",
    "Url": "http://lotr.wikia.com//wiki/May_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Samwise Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Samwise_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Gamling",
    "Url": "http://lotr.wikia.com//wiki/Gamling",
    "Race": "Human"
  },
  {
    "Name": "Elanor Gardner",
    "Url": "http://lotr.wikia.com//wiki/Elanor_Gardner",
    "Race": "Hobbit"
  },
  {
    "Name": "Gelmir",
    "Url": "http://lotr.wikia.com//wiki/Gelmir",
    "Race": "Elf"
  },
  {
    "Name": "Gelmir (of Angrod's kin)",
    "Url": "http://lotr.wikia.com//wiki/Gelmir_(of_Angrod%27s_kin)",
    "Race": "Elf"
  },
  {
    "Name": "Gethron",
    "Url": "http://lotr.wikia.com//wiki/Gethron",
    "Race": "Human"
  },
  {
    "Name": "Ghân-buri-Ghân",
    "Url": "http://lotr.wikia.com//wiki/Gh%C3%A2n-buri-Gh%C3%A2n",
    "Race": "Human"
  },
  {
    "Name": "Gil-galad",
    "Url": "http://lotr.wikia.com//wiki/Gil-galad",
    "Race": "Elf"
  },
  {
    "Name": "Gildis",
    "Url": "http://lotr.wikia.com//wiki/Gildis",
    "Race": "Human"
  },
  {
    "Name": "Gildor (Edain)",
    "Url": "http://lotr.wikia.com//wiki/Gildor_(Edain)",
    "Race": "Human"
  },
  {
    "Name": "Gildor Inglorion",
    "Url": "http://lotr.wikia.com//wiki/Gildor_Inglorion",
    "Race": "Elf"
  },
  {
    "Name": "Gilfanon",
    "Url": "http://lotr.wikia.com//wiki/Gilfanon",
    "Race": "Elf"
  },
  {
    "Name": "Gilraen",
    "Url": "http://lotr.wikia.com//wiki/Gilraen",
    "Race": "Human"
  },
  {
    "Name": "Gimilkhâd",
    "Url": "http://lotr.wikia.com//wiki/Gimilkh%C3%A2d",
    "Race": "Human"
  },
  {
    "Name": "Gimilzagar",
    "Url": "http://lotr.wikia.com//wiki/Gimilzagar",
    "Race": "Human"
  },
  {
    "Name": "Gimli",
    "Url": "http://lotr.wikia.com//wiki/Gimli",
    "Race": "Dwarf"
  },
  {
    "Name": "Girion",
    "Url": "http://lotr.wikia.com//wiki/Girion",
    "Race": "Human"
  },
  {
    "Name": "Glirhuin",
    "Url": "http://lotr.wikia.com//wiki/Glirhuin",
    "Race": "Human"
  },
  {
    "Name": "Glorfindel",
    "Url": "http://lotr.wikia.com//wiki/Glorfindel",
    "Race": "Elf"
  },
  {
    "Name": "Gléowine",
    "Url": "http://lotr.wikia.com//wiki/Gl%C3%A9owine",
    "Race": "Human"
  },
  {
    "Name": "Glóin",
    "Url": "http://lotr.wikia.com//wiki/Gl%C3%B3in",
    "Race": "Dwarf"
  },
  {
    "Name": "Glóin (King of Durin's Folk)",
    "Url": "http://lotr.wikia.com//wiki/Gl%C3%B3in_(King_of_Durin%27s_Folk)",
    "Race": "Dwarf"
  },
  {
    "Name": "Glóredhel",
    "Url": "http://lotr.wikia.com//wiki/Gl%C3%B3redhel",
    "Race": "Human"
  },
  {
    "Name": "Golasgil",
    "Url": "http://lotr.wikia.com//wiki/Golasgil",
    "Race": "Human"
  },
  {
    "Name": "Goldwine",
    "Url": "http://lotr.wikia.com//wiki/Goldwine",
    "Race": "Human"
  },
  {
    "Name": "Hanna (Goldworthy) Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Hanna_(Goldworthy)_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Gorbulas Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Gorbulas_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Gorhendad (Oldbuck) Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Gorhendad_(Oldbuck)_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Gorlim",
    "Url": "http://lotr.wikia.com//wiki/Gorlim",
    "Race": "Human"
  },
  {
    "Name": "Gormadoc Deepdelver Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Gormadoc_%22Deepdelver%22_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Gram",
    "Url": "http://lotr.wikia.com//wiki/Gram",
    "Race": "Human"
  },
  {
    "Name": "Erling Greenhand",
    "Url": "http://lotr.wikia.com//wiki/Erling_Greenhand",
    "Race": "Hobbit"
  },
  {
    "Name": "Halfred Greenhand",
    "Url": "http://lotr.wikia.com//wiki/Halfred_Greenhand",
    "Race": "Hobbit"
  },
  {
    "Name": "Hending Greenhand",
    "Url": "http://lotr.wikia.com//wiki/Hending_Greenhand",
    "Race": "Hobbit"
  },
  {
    "Name": "Holman Greenhand",
    "Url": "http://lotr.wikia.com//wiki/Holman_Greenhand",
    "Race": "Hobbit"
  },
  {
    "Name": "Rose Greenhand",
    "Url": "http://lotr.wikia.com//wiki/Rose_Greenhand",
    "Race": "Hobbit"
  },
  {
    "Name": "Grimbeorn",
    "Url": "http://lotr.wikia.com//wiki/Grimbeorn",
    "Race": "Human"
  },
  {
    "Name": "Grimbold",
    "Url": "http://lotr.wikia.com//wiki/Grimbold",
    "Race": "Human"
  },
  {
    "Name": "Grithnir",
    "Url": "http://lotr.wikia.com//wiki/Grithnir",
    "Race": "Human"
  },
  {
    "Name": "Gróin",
    "Url": "http://lotr.wikia.com//wiki/Gr%C3%B3in",
    "Race": "Dwarf"
  },
  {
    "Name": "Grór",
    "Url": "http://lotr.wikia.com//wiki/Gr%C3%B3r",
    "Race": "Dwarf"
  },
  {
    "Name": "Guilin",
    "Url": "http://lotr.wikia.com//wiki/Guilin",
    "Race": "Elf"
  },
  {
    "Name": "Gundor",
    "Url": "http://lotr.wikia.com//wiki/Gundor",
    "Race": "Human"
  },
  {
    "Name": "Guthláf",
    "Url": "http://lotr.wikia.com//wiki/Guthl%C3%A1f",
    "Race": "Human"
  },
  {
    "Name": "Gwindor",
    "Url": "http://lotr.wikia.com//wiki/Gwindor",
    "Race": "Elf"
  },
  {
    "Name": "Gálmód",
    "Url": "http://lotr.wikia.com//wiki/G%C3%A1lm%C3%B3d",
    "Race": "Human"
  },
  {
    "Name": "Gárulf",
    "Url": "http://lotr.wikia.com//wiki/G%C3%A1rulf",
    "Race": "Human"
  },
  {
    "Name": "Hador",
    "Url": "http://lotr.wikia.com//wiki/Hador",
    "Race": "Human"
  },
  {
    "Name": "Hador (Steward)",
    "Url": "http://lotr.wikia.com//wiki/Hador_(Steward)",
    "Race": "Human"
  },
  {
    "Name": "Halbarad",
    "Url": "http://lotr.wikia.com//wiki/Halbarad",
    "Race": "Human"
  },
  {
    "Name": "Haldir (Haladin)",
    "Url": "http://lotr.wikia.com//wiki/Haldir_(Haladin)",
    "Race": "Human"
  },
  {
    "Name": "Haldir (Lorien)",
    "Url": "http://lotr.wikia.com//wiki/Haldir_(Lorien)",
    "Race": "Elf"
  },
  {
    "Name": "Haleth",
    "Url": "http://lotr.wikia.com//wiki/Haleth",
    "Race": "Human"
  },
  {
    "Name": "Haleth (Helm's son)",
    "Url": "http://lotr.wikia.com//wiki/Haleth_(Helm%27s_son)",
    "Race": "Human"
  },
  {
    "Name": "Hallacar",
    "Url": "http://lotr.wikia.com//wiki/Hallacar",
    "Race": "Human"
  },
  {
    "Name": "Hallas (Steward)",
    "Url": "http://lotr.wikia.com//wiki/Hallas_(Steward)",
    "Race": "Human"
  },
  {
    "Name": "Hallatan",
    "Url": "http://lotr.wikia.com//wiki/Hallatan",
    "Race": "Human"
  },
  {
    "Name": "Halmir",
    "Url": "http://lotr.wikia.com//wiki/Halmir",
    "Race": "Human"
  },
  {
    "Name": "Hamfast of Gamwich",
    "Url": "http://lotr.wikia.com//wiki/Hamfast_of_Gamwich",
    "Race": "Hobbit"
  },
  {
    "Name": "Handir",
    "Url": "http://lotr.wikia.com//wiki/Handir",
    "Race": "Human"
  },
  {
    "Name": "Hardang",
    "Url": "http://lotr.wikia.com//wiki/Hardang",
    "Race": "Human"
  },
  {
    "Name": "Harding",
    "Url": "http://lotr.wikia.com//wiki/Harding",
    "Race": "Human"
  },
  {
    "Name": "Hareth",
    "Url": "http://lotr.wikia.com//wiki/Hareth",
    "Race": "Human"
  },
  {
    "Name": "Hathaldir",
    "Url": "http://lotr.wikia.com//wiki/Hathaldir",
    "Race": "Human"
  },
  {
    "Name": "Hathol",
    "Url": "http://lotr.wikia.com//wiki/Hathol",
    "Race": "Human"
  },
  {
    "Name": "Hatholdir",
    "Url": "http://lotr.wikia.com//wiki/Hatholdir",
    "Race": "Human"
  },
  {
    "Name": "Helm Hammerhand",
    "Url": "http://lotr.wikia.com//wiki/Helm_Hammerhand",
    "Race": "Human"
  },
  {
    "Name": "Henderch",
    "Url": "http://lotr.wikia.com//wiki/Henderch",
    "Race": "Human"
  },
  {
    "Name": "Hendor",
    "Url": "http://lotr.wikia.com//wiki/Hendor",
    "Race": "Elf"
  },
  {
    "Name": "Herefara",
    "Url": "http://lotr.wikia.com//wiki/Herefara",
    "Race": "Human"
  },
  {
    "Name": "Herion",
    "Url": "http://lotr.wikia.com//wiki/Herion",
    "Race": "Human"
  },
  {
    "Name": "Herubrand",
    "Url": "http://lotr.wikia.com//wiki/Herubrand",
    "Race": "Human"
  },
  {
    "Name": "Herucalmo",
    "Url": "http://lotr.wikia.com//wiki/Herucalmo",
    "Race": "Human"
  },
  {
    "Name": "Hirgon",
    "Url": "http://lotr.wikia.com//wiki/Hirgon",
    "Race": "Human"
  },
  {
    "Name": "Hirluin",
    "Url": "http://lotr.wikia.com//wiki/Hirluin",
    "Race": "Human"
  },
  {
    "Name": "Hob Gammidge",
    "Url": "http://lotr.wikia.com//wiki/Hob_Gammidge",
    "Race": "Hobbit"
  },
  {
    "Name": "Hob Hayward",
    "Url": "http://lotr.wikia.com//wiki/Hob_Hayward",
    "Race": "Hobbit"
  },
  {
    "Name": "Holfast Gardner",
    "Url": "http://lotr.wikia.com//wiki/Holfast_Gardner",
    "Race": "Hobbit"
  },
  {
    "Name": "Horn",
    "Url": "http://lotr.wikia.com//wiki/Horn",
    "Race": "Human"
  },
  {
    "Name": "Tobias Hornblower",
    "Url": "http://lotr.wikia.com//wiki/Tobias_Hornblower",
    "Race": "Hobbit"
  },
  {
    "Name": "Hundad",
    "Url": "http://lotr.wikia.com//wiki/Hundad",
    "Race": "Human"
  },
  {
    "Name": "Hundar",
    "Url": "http://lotr.wikia.com//wiki/Hundar",
    "Race": "Human"
  },
  {
    "Name": "Hunthor",
    "Url": "http://lotr.wikia.com//wiki/Hunthor",
    "Race": "Human"
  },
  {
    "Name": "Huor",
    "Url": "http://lotr.wikia.com//wiki/Huor",
    "Race": "Human"
  },
  {
    "Name": "Hyarmendacil I",
    "Url": "http://lotr.wikia.com//wiki/Hyarmendacil_I",
    "Race": "Human"
  },
  {
    "Name": "Hyarmendacil II",
    "Url": "http://lotr.wikia.com//wiki/Hyarmendacil_II",
    "Race": "Human"
  },
  {
    "Name": "Háma",
    "Url": "http://lotr.wikia.com//wiki/H%C3%A1ma",
    "Race": "Human"
  },
  {
    "Name": "Háma (Helm's son)",
    "Url": "http://lotr.wikia.com//wiki/H%C3%A1ma_(Helm%27s_son)",
    "Race": "Human"
  },
  {
    "Name": "Húrin",
    "Url": "http://lotr.wikia.com//wiki/H%C3%BArin",
    "Race": "Human"
  },
  {
    "Name": "Húrin I",
    "Url": "http://lotr.wikia.com//wiki/H%C3%BArin_I",
    "Race": "Human"
  },
  {
    "Name": "Húrin II",
    "Url": "http://lotr.wikia.com//wiki/H%C3%BArin_II",
    "Race": "Human"
  },
  {
    "Name": "Húrin of Emyn Arnen",
    "Url": "http://lotr.wikia.com//wiki/H%C3%BArin_of_Emyn_Arnen",
    "Race": "Human"
  },
  {
    "Name": "Ibûn",
    "Url": "http://lotr.wikia.com//wiki/Ib%C3%BBn",
    "Race": "Dwarf"
  },
  {
    "Name": "Idril",
    "Url": "http://lotr.wikia.com//wiki/Idril",
    "Race": "Elf"
  },
  {
    "Name": "Imin",
    "Url": "http://lotr.wikia.com//wiki/Imin",
    "Race": "Elf"
  },
  {
    "Name": "Iminyë",
    "Url": "http://lotr.wikia.com//wiki/Iminy%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Imlach",
    "Url": "http://lotr.wikia.com//wiki/Imlach",
    "Race": "Human"
  },
  {
    "Name": "Imrahil",
    "Url": "http://lotr.wikia.com//wiki/Imrahil",
    "Race": "Human"
  },
  {
    "Name": "Imrazôr",
    "Url": "http://lotr.wikia.com//wiki/Imraz%C3%B4r",
    "Race": "Human"
  },
  {
    "Name": "Indis",
    "Url": "http://lotr.wikia.com//wiki/Indis",
    "Race": "Elf"
  },
  {
    "Name": "Indor",
    "Url": "http://lotr.wikia.com//wiki/Indor",
    "Race": "Human"
  },
  {
    "Name": "Ingold",
    "Url": "http://lotr.wikia.com//wiki/Ingold",
    "Race": "Human"
  },
  {
    "Name": "Ingwion",
    "Url": "http://lotr.wikia.com//wiki/Ingwion",
    "Race": "Elf"
  },
  {
    "Name": "Ingwë",
    "Url": "http://lotr.wikia.com//wiki/Ingw%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Inzilbêth",
    "Url": "http://lotr.wikia.com//wiki/Inzilb%C3%AAth",
    "Race": "Human"
  },
  {
    "Name": "Ioreth",
    "Url": "http://lotr.wikia.com//wiki/Ioreth",
    "Race": "Human"
  },
  {
    "Name": "Iorlas",
    "Url": "http://lotr.wikia.com//wiki/Iorlas",
    "Race": "Human"
  },
  {
    "Name": "Isembold Took",
    "Url": "http://lotr.wikia.com//wiki/Isembold_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Isengrim Took III",
    "Url": "http://lotr.wikia.com//wiki/Isengrim_Took_III",
    "Race": "Hobbit"
  },
  {
    "Name": "Isildur",
    "Url": "http://lotr.wikia.com//wiki/Isildur",
    "Race": "Human"
  },
  {
    "Name": "Isilmo",
    "Url": "http://lotr.wikia.com//wiki/Isilmo",
    "Race": "Human"
  },
  {
    "Name": "Isilmë",
    "Url": "http://lotr.wikia.com//wiki/Isilm%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Ivorwen",
    "Url": "http://lotr.wikia.com//wiki/Ivorwen",
    "Race": "Human"
  },
  {
    "Name": "Ivriniel",
    "Url": "http://lotr.wikia.com//wiki/Ivriniel",
    "Race": "Human"
  },
  {
    "Name": "Lalaith",
    "Url": "http://lotr.wikia.com//wiki/Lalaith",
    "Race": "Human"
  },
  {
    "Name": "Larnach",
    "Url": "http://lotr.wikia.com//wiki/Larnach",
    "Race": "Human"
  },
  {
    "Name": "Legolas",
    "Url": "http://lotr.wikia.com//wiki/Legolas",
    "Race": "Elf"
  },
  {
    "Name": "Lenwë",
    "Url": "http://lotr.wikia.com//wiki/Lenw%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Lindir",
    "Url": "http://lotr.wikia.com//wiki/Lindir",
    "Race": "Elf"
  },
  {
    "Name": "Lindissë",
    "Url": "http://lotr.wikia.com//wiki/Lindiss%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Lindo",
    "Url": "http://lotr.wikia.com//wiki/Lindo",
    "Race": "Elf"
  },
  {
    "Name": "Lindórië",
    "Url": "http://lotr.wikia.com//wiki/Lind%C3%B3ri%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Lorgan",
    "Url": "http://lotr.wikia.com//wiki/Lorgan",
    "Race": "Human"
  },
  {
    "Name": "Lothíriel",
    "Url": "http://lotr.wikia.com//wiki/Loth%C3%ADriel",
    "Race": "Human"
  },
  {
    "Name": "Léod",
    "Url": "http://lotr.wikia.com//wiki/L%C3%A9od",
    "Race": "Human"
  },
  {
    "Name": "Brytta Léofa",
    "Url": "http://lotr.wikia.com//wiki/Brytta_L%C3%A9ofa",
    "Race": "Human"
  },
  {
    "Name": "Lóni",
    "Url": "http://lotr.wikia.com//wiki/L%C3%B3ni",
    "Race": "Dwarf"
  },
  {
    "Name": "Lúthien",
    "Url": "http://lotr.wikia.com//wiki/L%C3%BAthien",
    "Race": "Elf"
  },
  {
    "Name": "Mablung the Ranger",
    "Url": "http://lotr.wikia.com//wiki/Mablung_the_Ranger",
    "Race": "Human"
  },
  {
    "Name": "Maedhros",
    "Url": "http://lotr.wikia.com//wiki/Maedhros",
    "Race": "Elf"
  },
  {
    "Name": "Maeglin",
    "Url": "http://lotr.wikia.com//wiki/Maeglin",
    "Race": "Elf"
  },
  {
    "Name": "Farmer Maggot",
    "Url": "http://lotr.wikia.com//wiki/Farmer_Maggot",
    "Race": "Hobbit"
  },
  {
    "Name": "Maglor",
    "Url": "http://lotr.wikia.com//wiki/Maglor",
    "Race": "Elf"
  },
  {
    "Name": "Magor",
    "Url": "http://lotr.wikia.com//wiki/Magor",
    "Race": "Human"
  },
  {
    "Name": "Mahtan",
    "Url": "http://lotr.wikia.com//wiki/Mahtan",
    "Race": "Elf"
  },
  {
    "Name": "Mairen",
    "Url": "http://lotr.wikia.com//wiki/Mairen",
    "Race": "Human"
  },
  {
    "Name": "Malach",
    "Url": "http://lotr.wikia.com//wiki/Malach",
    "Race": "Human"
  },
  {
    "Name": "Malbeth the Seer",
    "Url": "http://lotr.wikia.com//wiki/Malbeth_the_Seer",
    "Race": "Human"
  },
  {
    "Name": "Mallor",
    "Url": "http://lotr.wikia.com//wiki/Mallor",
    "Race": "Human"
  },
  {
    "Name": "Malva Headstrong Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Malva_%22Headstrong%22_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Malvegil",
    "Url": "http://lotr.wikia.com//wiki/Malvegil",
    "Race": "Human"
  },
  {
    "Name": "Manthor",
    "Url": "http://lotr.wikia.com//wiki/Manthor",
    "Race": "Human"
  },
  {
    "Name": "Manwendil",
    "Url": "http://lotr.wikia.com//wiki/Manwendil",
    "Race": "Human"
  },
  {
    "Name": "Marach",
    "Url": "http://lotr.wikia.com//wiki/Marach",
    "Race": "Human"
  },
  {
    "Name": "Marcho",
    "Url": "http://lotr.wikia.com//wiki/Marcho",
    "Race": "Hobbit"
  },
  {
    "Name": "Mardil Voronwë",
    "Url": "http://lotr.wikia.com//wiki/Mardil_Voronw%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Marhari",
    "Url": "http://lotr.wikia.com//wiki/Marhari",
    "Race": "Human"
  },
  {
    "Name": "Marhwini",
    "Url": "http://lotr.wikia.com//wiki/Marhwini",
    "Race": "Human"
  },
  {
    "Name": "Marmadas Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Marmadas_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Marroc Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Marroc_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Master of Laketown",
    "Url": "http://lotr.wikia.com//wiki/Master_of_Laketown",
    "Race": "Human"
  },
  {
    "Name": "Meleth",
    "Url": "http://lotr.wikia.com//wiki/Meleth",
    "Race": "Human"
  },
  {
    "Name": "Meneldil",
    "Url": "http://lotr.wikia.com//wiki/Meneldil",
    "Race": "Human"
  },
  {
    "Name": "Meril-i-Turinqi",
    "Url": "http://lotr.wikia.com//wiki/Meril-i-Turinqi",
    "Race": "Elf"
  },
  {
    "Name": "Merimas Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Merimas_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Minardil",
    "Url": "http://lotr.wikia.com//wiki/Minardil",
    "Race": "Human"
  },
  {
    "Name": "Minohtar",
    "Url": "http://lotr.wikia.com//wiki/Minohtar",
    "Race": "Human"
  },
  {
    "Name": "Mithrellas",
    "Url": "http://lotr.wikia.com//wiki/Mithrellas",
    "Race": "Elf"
  },
  {
    "Name": "Morwen",
    "Url": "http://lotr.wikia.com//wiki/Morwen",
    "Race": "Human"
  },
  {
    "Name": "Morwen (Gondor)",
    "Url": "http://lotr.wikia.com//wiki/Morwen_(Gondor)",
    "Race": "Human"
  },
  {
    "Name": "Morwë",
    "Url": "http://lotr.wikia.com//wiki/Morw%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Míriel",
    "Url": "http://lotr.wikia.com//wiki/M%C3%ADriel",
    "Race": "Elf"
  },
  {
    "Name": "Mîm",
    "Url": "http://lotr.wikia.com//wiki/M%C3%AEm",
    "Race": "Dwarf"
  },
  {
    "Name": "Narmacil I",
    "Url": "http://lotr.wikia.com//wiki/Narmacil_I",
    "Race": "Human"
  },
  {
    "Name": "Narmacil II",
    "Url": "http://lotr.wikia.com//wiki/Narmacil_II",
    "Race": "Human"
  },
  {
    "Name": "Naugladur",
    "Url": "http://lotr.wikia.com//wiki/Naugladur",
    "Race": "Dwarf"
  },
  {
    "Name": "Nerdanel",
    "Url": "http://lotr.wikia.com//wiki/Nerdanel",
    "Race": "Elf"
  },
  {
    "Name": "Nessanië",
    "Url": "http://lotr.wikia.com//wiki/Nessani%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Nimrodel",
    "Url": "http://lotr.wikia.com//wiki/Nimrodel",
    "Race": "Elf"
  },
  {
    "Name": "Nina Lightfoot",
    "Url": "http://lotr.wikia.com//wiki/Nina_Lightfoot",
    "Race": "Hobbit"
  },
  {
    "Name": "Niënor",
    "Url": "http://lotr.wikia.com//wiki/Ni%C3%ABnor",
    "Race": "Human"
  },
  {
    "Name": "Nob",
    "Url": "http://lotr.wikia.com//wiki/Nob",
    "Race": "Hobbit"
  },
  {
    "Name": "Nolondil",
    "Url": "http://lotr.wikia.com//wiki/Nolondil",
    "Race": "Human"
  },
  {
    "Name": "Nori",
    "Url": "http://lotr.wikia.com//wiki/Nori",
    "Race": "Dwarf"
  },
  {
    "Name": "Nurwë",
    "Url": "http://lotr.wikia.com//wiki/Nurw%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Náin (father of Dáin II Ironfoot)",
    "Url": "http://lotr.wikia.com//wiki/N%C3%A1in_(father_of_D%C3%A1in_II_Ironfoot)",
    "Race": "Dwarf"
  },
  {
    "Name": "Náin I",
    "Url": "http://lotr.wikia.com//wiki/N%C3%A1in_I",
    "Race": "Dwarf"
  },
  {
    "Name": "Náin II",
    "Url": "http://lotr.wikia.com//wiki/N%C3%A1in_II",
    "Race": "Dwarf"
  },
  {
    "Name": "Náli",
    "Url": "http://lotr.wikia.com//wiki/N%C3%A1li",
    "Race": "Dwarf"
  },
  {
    "Name": "Nár",
    "Url": "http://lotr.wikia.com//wiki/N%C3%A1r",
    "Race": "Dwarf"
  },
  {
    "Name": "Númendil",
    "Url": "http://lotr.wikia.com//wiki/N%C3%BAmendil",
    "Race": "Human"
  },
  {
    "Name": "Núneth",
    "Url": "http://lotr.wikia.com//wiki/N%C3%BAneth",
    "Race": "Human"
  },
  {
    "Name": "Ohtar",
    "Url": "http://lotr.wikia.com//wiki/Ohtar",
    "Race": "Human"
  },
  {
    "Name": "Old Noakes",
    "Url": "http://lotr.wikia.com//wiki/Old_Noakes",
    "Race": "Hobbit"
  },
  {
    "Name": "Olwë",
    "Url": "http://lotr.wikia.com//wiki/Olw%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Ondoher",
    "Url": "http://lotr.wikia.com//wiki/Ondoher",
    "Race": "Human"
  },
  {
    "Name": "Orchaldor",
    "Url": "http://lotr.wikia.com//wiki/Orchaldor",
    "Race": "Human"
  },
  {
    "Name": "Ori",
    "Url": "http://lotr.wikia.com//wiki/Ori",
    "Race": "Dwarf"
  },
  {
    "Name": "Orodreth",
    "Url": "http://lotr.wikia.com//wiki/Orodreth",
    "Race": "Elf"
  },
  {
    "Name": "Orodreth (Steward)",
    "Url": "http://lotr.wikia.com//wiki/Orodreth_(Steward)",
    "Race": "Human"
  },
  {
    "Name": "Oromendil",
    "Url": "http://lotr.wikia.com//wiki/Oromendil",
    "Race": "Human"
  },
  {
    "Name": "Oropher",
    "Url": "http://lotr.wikia.com//wiki/Oropher",
    "Race": "Elf"
  },
  {
    "Name": "Orophin",
    "Url": "http://lotr.wikia.com//wiki/Orophin",
    "Race": "Elf"
  },
  {
    "Name": "Ostoher",
    "Url": "http://lotr.wikia.com//wiki/Ostoher",
    "Race": "Human"
  },
  {
    "Name": "Otho Sackville-Baggins",
    "Url": "http://lotr.wikia.com//wiki/Otho_Sackville-Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Pelendur",
    "Url": "http://lotr.wikia.com//wiki/Pelendur",
    "Race": "Human"
  },
  {
    "Name": "Pengolodh",
    "Url": "http://lotr.wikia.com//wiki/Pengolodh",
    "Race": "Elf"
  },
  {
    "Name": "Mrs. Proudfoot",
    "Url": "http://lotr.wikia.com//wiki/Mrs._Proudfoot",
    "Race": "Hobbit"
  },
  {
    "Name": "Odo Proudfoot",
    "Url": "http://lotr.wikia.com//wiki/Odo_Proudfoot",
    "Race": "Hobbit"
  },
  {
    "Name": "Radhruin",
    "Url": "http://lotr.wikia.com//wiki/Radhruin",
    "Race": "Human"
  },
  {
    "Name": "Ragnir",
    "Url": "http://lotr.wikia.com//wiki/Ragnir",
    "Race": "Human"
  },
  {
    "Name": "Ragnor",
    "Url": "http://lotr.wikia.com//wiki/Ragnor",
    "Race": "Human"
  },
  {
    "Name": "Rowan Greenhand",
    "Url": "http://lotr.wikia.com//wiki/Rowan_Greenhand",
    "Race": "Hobbit"
  },
  {
    "Name": "Rudigar Bolger",
    "Url": "http://lotr.wikia.com//wiki/Rudigar_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Rufus Burrows",
    "Url": "http://lotr.wikia.com//wiki/Rufus_Burrows",
    "Race": "Hobbit"
  },
  {
    "Name": "Rían",
    "Url": "http://lotr.wikia.com//wiki/R%C3%ADan",
    "Race": "Human"
  },
  {
    "Name": "Rían (Gondor)",
    "Url": "http://lotr.wikia.com//wiki/R%C3%ADan_(Gondor)",
    "Race": "Human"
  },
  {
    "Name": "Rómendacil I",
    "Url": "http://lotr.wikia.com//wiki/R%C3%B3mendacil_I",
    "Race": "Human"
  },
  {
    "Name": "Rómendacil II",
    "Url": "http://lotr.wikia.com//wiki/R%C3%B3mendacil_II",
    "Race": "Human"
  },
  {
    "Name": "Rúmil (Noldo)",
    "Url": "http://lotr.wikia.com//wiki/R%C3%BAmil_(Noldo)",
    "Race": "Elf"
  },
  {
    "Name": "Rúmil of Lórien",
    "Url": "http://lotr.wikia.com//wiki/R%C3%BAmil_of_L%C3%B3rien",
    "Race": "Elf"
  },
  {
    "Name": "Lobelia Sackville-Baggins",
    "Url": "http://lotr.wikia.com//wiki/Lobelia_Sackville-Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Lotho Sackville-Baggins",
    "Url": "http://lotr.wikia.com//wiki/Lotho_Sackville-Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Sadoc Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Sadoc_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Sador",
    "Url": "http://lotr.wikia.com//wiki/Sador",
    "Race": "Human"
  },
  {
    "Name": "Saelon",
    "Url": "http://lotr.wikia.com//wiki/Saelon",
    "Race": "Human"
  },
  {
    "Name": "Sagroth",
    "Url": "http://lotr.wikia.com//wiki/Sagroth",
    "Race": "Human"
  },
  {
    "Name": "Ted Sandyman",
    "Url": "http://lotr.wikia.com//wiki/Ted_Sandyman",
    "Race": "Hobbit"
  },
  {
    "Name": "Sangahyando",
    "Url": "http://lotr.wikia.com//wiki/Sangahyando",
    "Race": "Human"
  },
  {
    "Name": "Saradas Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Saradas_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Silmariën",
    "Url": "http://lotr.wikia.com//wiki/Silmari%C3%ABn",
    "Race": "Human"
  },
  {
    "Name": "Siriondil",
    "Url": "http://lotr.wikia.com//wiki/Siriondil",
    "Race": "Human"
  },
  {
    "Name": "Robin Smallburrow",
    "Url": "http://lotr.wikia.com//wiki/Robin_Smallburrow",
    "Race": "Hobbit"
  },
  {
    "Name": "Soronto",
    "Url": "http://lotr.wikia.com//wiki/Soronto",
    "Race": "Human"
  },
  {
    "Name": "Morwen Steelsheen",
    "Url": "http://lotr.wikia.com//wiki/Morwen_Steelsheen",
    "Race": "Human"
  },
  {
    "Name": "Tar-Alcarin",
    "Url": "http://lotr.wikia.com//wiki/Tar-Alcarin",
    "Race": "Human"
  },
  {
    "Name": "Tar-Aldarion",
    "Url": "http://lotr.wikia.com//wiki/Tar-Aldarion",
    "Race": "Human"
  },
  {
    "Name": "Tar-Amandil",
    "Url": "http://lotr.wikia.com//wiki/Tar-Amandil",
    "Race": "Human"
  },
  {
    "Name": "Tar-Ancalimon",
    "Url": "http://lotr.wikia.com//wiki/Tar-Ancalimon",
    "Race": "Human"
  },
  {
    "Name": "Tar-Ancalimë",
    "Url": "http://lotr.wikia.com//wiki/Tar-Ancalim%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Tar-Anárion",
    "Url": "http://lotr.wikia.com//wiki/Tar-An%C3%A1rion",
    "Race": "Human"
  },
  {
    "Name": "Tar-Ardamin",
    "Url": "http://lotr.wikia.com//wiki/Tar-Ardamin",
    "Race": "Human"
  },
  {
    "Name": "Tar-Atanamir",
    "Url": "http://lotr.wikia.com//wiki/Tar-Atanamir",
    "Race": "Human"
  },
  {
    "Name": "Tar-Calmacil",
    "Url": "http://lotr.wikia.com//wiki/Tar-Calmacil",
    "Race": "Human"
  },
  {
    "Name": "Tar-Ciryatan",
    "Url": "http://lotr.wikia.com//wiki/Tar-Ciryatan",
    "Race": "Human"
  },
  {
    "Name": "Tar-Elendil",
    "Url": "http://lotr.wikia.com//wiki/Tar-Elendil",
    "Race": "Human"
  },
  {
    "Name": "Tar-Meneldur",
    "Url": "http://lotr.wikia.com//wiki/Tar-Meneldur",
    "Race": "Human"
  },
  {
    "Name": "Tar-Minastir",
    "Url": "http://lotr.wikia.com//wiki/Tar-Minastir",
    "Race": "Human"
  },
  {
    "Name": "Tar-Míriel",
    "Url": "http://lotr.wikia.com//wiki/Tar-M%C3%ADriel",
    "Race": "Human"
  },
  {
    "Name": "Tar-Palantir",
    "Url": "http://lotr.wikia.com//wiki/Tar-Palantir",
    "Race": "Human"
  },
  {
    "Name": "Tar-Súrion",
    "Url": "http://lotr.wikia.com//wiki/Tar-S%C3%BArion",
    "Race": "Human"
  },
  {
    "Name": "Tar-Telemmaitë",
    "Url": "http://lotr.wikia.com//wiki/Tar-Telemmait%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Tar-Telperiën",
    "Url": "http://lotr.wikia.com//wiki/Tar-Telperi%C3%ABn",
    "Race": "Human"
  },
  {
    "Name": "Tar-Vanimeldë",
    "Url": "http://lotr.wikia.com//wiki/Tar-Vanimeld%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Tarannon Falastur",
    "Url": "http://lotr.wikia.com//wiki/Tarannon_Falastur",
    "Race": "Human"
  },
  {
    "Name": "Tarcil",
    "Url": "http://lotr.wikia.com//wiki/Tarcil",
    "Race": "Human"
  },
  {
    "Name": "Tarciryan",
    "Url": "http://lotr.wikia.com//wiki/Tarciryan",
    "Race": "Human"
  },
  {
    "Name": "Targon",
    "Url": "http://lotr.wikia.com//wiki/Targon",
    "Race": "Human"
  },
  {
    "Name": "Tarondor",
    "Url": "http://lotr.wikia.com//wiki/Tarondor",
    "Race": "Human"
  },
  {
    "Name": "Tarondor of Arnor",
    "Url": "http://lotr.wikia.com//wiki/Tarondor_of_Arnor",
    "Race": "Human"
  },
  {
    "Name": "Tata",
    "Url": "http://lotr.wikia.com//wiki/Tata",
    "Race": "Elf"
  },
  {
    "Name": "Tatië",
    "Url": "http://lotr.wikia.com//wiki/Tati%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Telchar",
    "Url": "http://lotr.wikia.com//wiki/Telchar",
    "Race": "Dwarf"
  },
  {
    "Name": "Telemnar",
    "Url": "http://lotr.wikia.com//wiki/Telemnar",
    "Race": "Human"
  },
  {
    "Name": "Telumehtar",
    "Url": "http://lotr.wikia.com//wiki/Telumehtar",
    "Race": "Human"
  },
  {
    "Name": "The King of the Dead",
    "Url": "http://lotr.wikia.com//wiki/The_King_of_the_Dead",
    "Race": "Human"
  },
  {
    "Name": "Thengel",
    "Url": "http://lotr.wikia.com//wiki/Thengel",
    "Race": "Human"
  },
  {
    "Name": "Thorin I",
    "Url": "http://lotr.wikia.com//wiki/Thorin_I",
    "Race": "Dwarf"
  },
  {
    "Name": "Thorin II Oakenshield",
    "Url": "http://lotr.wikia.com//wiki/Thorin_II_Oakenshield",
    "Race": "Dwarf"
  },
  {
    "Name": "Thorin III Stonehelm",
    "Url": "http://lotr.wikia.com//wiki/Thorin_III_Stonehelm",
    "Race": "Dwarf"
  },
  {
    "Name": "Thorondir",
    "Url": "http://lotr.wikia.com//wiki/Thorondir",
    "Race": "Human"
  },
  {
    "Name": "Thranduil",
    "Url": "http://lotr.wikia.com//wiki/Thranduil",
    "Race": "Elf"
  },
  {
    "Name": "Thráin I",
    "Url": "http://lotr.wikia.com//wiki/Thr%C3%A1in_I",
    "Race": "Dwarf"
  },
  {
    "Name": "Thráin II",
    "Url": "http://lotr.wikia.com//wiki/Thr%C3%A1in_II",
    "Race": "Dwarf"
  },
  {
    "Name": "Thrór",
    "Url": "http://lotr.wikia.com//wiki/Thr%C3%B3r",
    "Race": "Dwarf"
  },
  {
    "Name": "Théoden",
    "Url": "http://lotr.wikia.com//wiki/Th%C3%A9oden",
    "Race": "Human"
  },
  {
    "Name": "Théodred",
    "Url": "http://lotr.wikia.com//wiki/Th%C3%A9odred",
    "Race": "Human"
  },
  {
    "Name": "Tindómiel",
    "Url": "http://lotr.wikia.com//wiki/Tind%C3%B3miel",
    "Race": "Human"
  },
  {
    "Name": "Faramir Took I",
    "Url": "http://lotr.wikia.com//wiki/Faramir_Took_I",
    "Race": "Hobbit"
  },
  {
    "Name": "Isumbras Took I",
    "Url": "http://lotr.wikia.com//wiki/Isumbras_Took_I",
    "Race": "Hobbit"
  },
  {
    "Name": "Fortinbras Took II",
    "Url": "http://lotr.wikia.com//wiki/Fortinbras_Took_II",
    "Race": "Hobbit"
  },
  {
    "Name": "Isengrim Took II",
    "Url": "http://lotr.wikia.com//wiki/Isengrim_Took_II",
    "Race": "Hobbit"
  },
  {
    "Name": "Isumbras Took III",
    "Url": "http://lotr.wikia.com//wiki/Isumbras_Took_III",
    "Race": "Hobbit"
  },
  {
    "Name": "Adalgrim Took",
    "Url": "http://lotr.wikia.com//wiki/Adalgrim_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Adamanta (Chubb) Took",
    "Url": "http://lotr.wikia.com//wiki/Adamanta_(Chubb)_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Adelard Took",
    "Url": "http://lotr.wikia.com//wiki/Adelard_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Bandobras Took",
    "Url": "http://lotr.wikia.com//wiki/Bandobras_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Ferumbras III Took",
    "Url": "http://lotr.wikia.com//wiki/Ferumbras_III_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Gerontius Took",
    "Url": "http://lotr.wikia.com//wiki/Gerontius_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Hildibrand Took",
    "Url": "http://lotr.wikia.com//wiki/Hildibrand_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Hildifons Took",
    "Url": "http://lotr.wikia.com//wiki/Hildifons_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Hildigrim Took",
    "Url": "http://lotr.wikia.com//wiki/Hildigrim_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Isembard Took",
    "Url": "http://lotr.wikia.com//wiki/Isembard_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Paladin Took II",
    "Url": "http://lotr.wikia.com//wiki/Paladin_Took_II",
    "Race": "Hobbit"
  },
  {
    "Name": "Pearl Took",
    "Url": "http://lotr.wikia.com//wiki/Pearl_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Peregrin Took",
    "Url": "http://lotr.wikia.com//wiki/Peregrin_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Rosa (Baggins) Took",
    "Url": "http://lotr.wikia.com//wiki/Rosa_(Baggins)_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Sigismond Took",
    "Url": "http://lotr.wikia.com//wiki/Sigismond_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Tulkastor",
    "Url": "http://lotr.wikia.com//wiki/Tulkastor",
    "Race": "Elf"
  },
  {
    "Name": "Tuor",
    "Url": "http://lotr.wikia.com//wiki/Tuor",
    "Race": "Human"
  },
  {
    "Name": "Turambar",
    "Url": "http://lotr.wikia.com//wiki/Turambar",
    "Race": "Human"
  },
  {
    "Name": "Turgon",
    "Url": "http://lotr.wikia.com//wiki/Turgon",
    "Race": "Elf"
  },
  {
    "Name": "Turgon (Steward)",
    "Url": "http://lotr.wikia.com//wiki/Turgon_(Steward)",
    "Race": "Human"
  },
  {
    "Name": "Túrin",
    "Url": "http://lotr.wikia.com//wiki/T%C3%BArin",
    "Race": "Human"
  },
  {
    "Name": "Túrin I",
    "Url": "http://lotr.wikia.com//wiki/T%C3%BArin_I",
    "Race": "Human"
  },
  {
    "Name": "Túrin II",
    "Url": "http://lotr.wikia.com//wiki/T%C3%BArin_II",
    "Race": "Human"
  },
  {
    "Name": "Ulbar",
    "Url": "http://lotr.wikia.com//wiki/Ulbar",
    "Race": "Human"
  },
  {
    "Name": "Uldor",
    "Url": "http://lotr.wikia.com//wiki/Uldor",
    "Race": "Human"
  },
  {
    "Name": "Ulfang",
    "Url": "http://lotr.wikia.com//wiki/Ulfang",
    "Race": "Human"
  },
  {
    "Name": "Ulfast",
    "Url": "http://lotr.wikia.com//wiki/Ulfast",
    "Race": "Human"
  },
  {
    "Name": "Ulwarth",
    "Url": "http://lotr.wikia.com//wiki/Ulwarth",
    "Race": "Human"
  },
  {
    "Name": "Urthel",
    "Url": "http://lotr.wikia.com//wiki/Urthel",
    "Race": "Human"
  },
  {
    "Name": "Vairë (Elf)",
    "Url": "http://lotr.wikia.com//wiki/Vair%C3%AB_(Elf)",
    "Race": "Elf"
  },
  {
    "Name": "Valacar",
    "Url": "http://lotr.wikia.com//wiki/Valacar",
    "Race": "Human"
  },
  {
    "Name": "Valandil",
    "Url": "http://lotr.wikia.com//wiki/Valandil",
    "Race": "Human"
  },
  {
    "Name": "Valandil of Andúnië",
    "Url": "http://lotr.wikia.com//wiki/Valandil_of_And%C3%BAni%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Valandur",
    "Url": "http://lotr.wikia.com//wiki/Valandur",
    "Race": "Human"
  },
  {
    "Name": "Vardamir Nólimon",
    "Url": "http://lotr.wikia.com//wiki/Vardamir_N%C3%B3limon",
    "Race": "Human"
  },
  {
    "Name": "Vardilmë",
    "Url": "http://lotr.wikia.com//wiki/Vardilm%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Vidugavia",
    "Url": "http://lotr.wikia.com//wiki/Vidugavia",
    "Race": "Human"
  },
  {
    "Name": "Vidumavi",
    "Url": "http://lotr.wikia.com//wiki/Vidumavi",
    "Race": "Human"
  },
  {
    "Name": "Vorondil",
    "Url": "http://lotr.wikia.com//wiki/Vorondil",
    "Race": "Human"
  },
  {
    "Name": "Voronwë",
    "Url": "http://lotr.wikia.com//wiki/Voronw%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Vëantur",
    "Url": "http://lotr.wikia.com//wiki/V%C3%ABantur",
    "Race": "Human"
  },
  {
    "Name": "Walda",
    "Url": "http://lotr.wikia.com//wiki/Walda",
    "Race": "Human"
  },
  {
    "Name": "Willie Banks",
    "Url": "http://lotr.wikia.com//wiki/Willie_Banks",
    "Race": "Hobbit"
  },
  {
    "Name": "Wiseman Gamwich",
    "Url": "http://lotr.wikia.com//wiki/Wiseman_Gamwich",
    "Race": "Hobbit"
  },
  {
    "Name": "Wulf I",
    "Url": "http://lotr.wikia.com//wiki/Wulf_I",
    "Race": "Human"
  },
  {
    "Name": "Wídfara",
    "Url": "http://lotr.wikia.com//wiki/W%C3%ADdfara",
    "Race": "Human"
  },
  {
    "Name": "Yávien",
    "Url": "http://lotr.wikia.com//wiki/Y%C3%A1vien",
    "Race": "Human"
  },
  {
    "Name": "Éofor",
    "Url": "http://lotr.wikia.com//wiki/%C3%89ofor",
    "Race": "Human"
  },
  {
    "Name": "Éomund",
    "Url": "http://lotr.wikia.com//wiki/%C3%89omund",
    "Race": "Human"
  },
  {
    "Name": "Éothain",
    "Url": "http://lotr.wikia.com//wiki/%C3%89othain",
    "Race": "Human"
  },
  {
    "Name": "Írildë",
    "Url": "http://lotr.wikia.com//wiki/%C3%8Drild%C3%AB",
    "Race": "Human"
  },
  {
    "Name": "Írimë",
    "Url": "http://lotr.wikia.com//wiki/%C3%8Drim%C3%AB",
    "Race": "Elf"
  },
  {
    "Name": "Óin",
    "Url": "http://lotr.wikia.com//wiki/%C3%93in",
    "Race": "Dwarf"
  },
  {
    "Name": "Óin (King of Durin's Folk)",
    "Url": "http://lotr.wikia.com//wiki/%C3%93in_(King_of_Durin%27s_Folk)",
    "Race": "Dwarf"
  },
  {
    "Name": "Bingo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Bingo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Chica (Chubb) Baggins",
    "Url": "http://lotr.wikia.com//wiki/Chica_(Chubb)_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Dora Baggins",
    "Url": "http://lotr.wikia.com//wiki/Dora_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Largo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Largo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Mimosa (Bunce) Baggins",
    "Url": "http://lotr.wikia.com//wiki/Mimosa_(Bunce)_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Pansy Baggins",
    "Url": "http://lotr.wikia.com//wiki/Pansy_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Polo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Polo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Ponto Baggins I",
    "Url": "http://lotr.wikia.com//wiki/Ponto_Baggins_I",
    "Race": "Hobbit"
  },
  {
    "Name": "Ruby (Bolger) Baggins",
    "Url": "http://lotr.wikia.com//wiki/Ruby_(Bolger)_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Adalgar Bolger",
    "Url": "http://lotr.wikia.com//wiki/Adalgar_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Gundahar Bolger",
    "Url": "http://lotr.wikia.com//wiki/Gundahar_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Prisca (Baggins) Bolger",
    "Url": "http://lotr.wikia.com//wiki/Prisca_(Baggins)_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Rudibert Bolger",
    "Url": "http://lotr.wikia.com//wiki/Rudibert_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Theobald Bolger",
    "Url": "http://lotr.wikia.com//wiki/Theobald_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Wilimar Bolger",
    "Url": "http://lotr.wikia.com//wiki/Wilimar_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Camellia (Sackville) Baggins",
    "Url": "http://lotr.wikia.com//wiki/Camellia_(Sackville)_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Everard Took",
    "Url": "http://lotr.wikia.com//wiki/Everard_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Ferdibrand Took",
    "Url": "http://lotr.wikia.com//wiki/Ferdibrand_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Ferdinand Took",
    "Url": "http://lotr.wikia.com//wiki/Ferdinand_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Flambard Took",
    "Url": "http://lotr.wikia.com//wiki/Flambard_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Lalia (Clayhanger) Took",
    "Url": "http://lotr.wikia.com//wiki/Lalia_(Clayhanger)_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Pervinca Took",
    "Url": "http://lotr.wikia.com//wiki/Pervinca_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Pimpernel Took",
    "Url": "http://lotr.wikia.com//wiki/Pimpernel_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Reginard Took",
    "Url": "http://lotr.wikia.com//wiki/Reginard_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Ruby Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Ruby_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Rudolph Bolger",
    "Url": "http://lotr.wikia.com//wiki/Rudolph_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Tanta (Hornblower) Baggins",
    "Url": "http://lotr.wikia.com//wiki/Tanta_(Hornblower)_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Inigo Baggins",
    "Url": "http://lotr.wikia.com//wiki/Inigo_Baggins",
    "Race": "Hobbit"
  },
  {
    "Name": "Tanta Hornblower",
    "Url": "http://lotr.wikia.com//wiki/Tanta_Hornblower",
    "Race": "Hobbit"
  },
  {
    "Name": "Tobold Hornblower",
    "Url": "http://lotr.wikia.com//wiki/Tobold_Hornblower",
    "Race": "Hobbit"
  },
  {
    "Name": "Lily (Baggins) Goodbody",
    "Url": "http://lotr.wikia.com//wiki/Lily_(Baggins)_Goodbody",
    "Race": "Hobbit"
  },
  {
    "Name": "Bell (Goodchild) Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Bell_(Goodchild)_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Togo Goodbody",
    "Url": "http://lotr.wikia.com//wiki/Togo_Goodbody",
    "Race": "Hobbit"
  },
  {
    "Name": "Goldberry",
    "Url": "http://lotr.wikia.com//wiki/Goldberry",
    "Race": "Hobbit"
  },
  {
    "Name": "Goldilocks (Gardner) Took",
    "Url": "http://lotr.wikia.com//wiki/Goldilocks_(Gardner)_Took",
    "Race": "Hobbit"
  },
  {
    "Name": "Merry Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Merry_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Bilbo Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Bilbo_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Halfast Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Halfast_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Rose Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Rose_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Hamfast Gardner",
    "Url": "http://lotr.wikia.com//wiki/Hamfast_Gardner",
    "Race": "Hobbit"
  },
  {
    "Name": "Pippin Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Pippin_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Primrose Gardner",
    "Url": "http://lotr.wikia.com//wiki/Primrose_Gardner",
    "Race": "Hobbit"
  },
  {
    "Name": "Robin Gardner",
    "Url": "http://lotr.wikia.com//wiki/Robin_Gardner",
    "Race": "Hobbit"
  },
  {
    "Name": "Durin",
    "Url": "http://lotr.wikia.com//wiki/Durin",
    "Race": "Dwarf"
  },
  {
    "Name": "Poppy (Chubb-Baggins) Bolger",
    "Url": "http://lotr.wikia.com//wiki/Poppy_(Chubb-Baggins)_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Tolman Cotton Jr.",
    "Url": "http://lotr.wikia.com//wiki/Tolman_Cotton_Jr.",
    "Race": "Hobbit"
  },
  {
    "Name": "Carl Cotton",
    "Url": "http://lotr.wikia.com//wiki/Carl_Cotton",
    "Race": "Hobbit"
  },
  {
    "Name": "Wilcome Cotton",
    "Url": "http://lotr.wikia.com//wiki/Wilcome_Cotton",
    "Race": "Hobbit"
  },
  {
    "Name": "Daisy Gamgee",
    "Url": "http://lotr.wikia.com//wiki/Daisy_Gamgee",
    "Race": "Hobbit"
  },
  {
    "Name": "Berilac Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Berilac_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Doderic Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Doderic_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Gorbadoc Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Gorbadoc_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Ilberic Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Ilberic_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Marmadoc Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Marmadoc_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Merimac Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Merimac_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Orgulas Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Orgulas_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Rorimac Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Rorimac_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Salvia (Brandybuck) Bolger",
    "Url": "http://lotr.wikia.com//wiki/Salvia_(Brandybuck)_Bolger",
    "Race": "Hobbit"
  },
  {
    "Name": "Bilbo Gardner",
    "Url": "http://lotr.wikia.com//wiki/Bilbo_Gardner",
    "Race": "Hobbit"
  },
  {
    "Name": "Briffo Boffin",
    "Url": "http://lotr.wikia.com//wiki/Briffo_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Gruffo Boffin",
    "Url": "http://lotr.wikia.com//wiki/Gruffo_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Lavender (Grubb) Boffin",
    "Url": "http://lotr.wikia.com//wiki/Lavender_(Grubb)_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Uffo Boffin",
    "Url": "http://lotr.wikia.com//wiki/Uffo_Boffin",
    "Race": "Hobbit"
  },
  {
    "Name": "Bodo Proudfoot",
    "Url": "http://lotr.wikia.com//wiki/Bodo_Proudfoot",
    "Race": "Hobbit"
  },
  {
    "Name": "Linda (Baggins) Proudfoot",
    "Url": "http://lotr.wikia.com//wiki/Linda_(Baggins)_Proudfoot",
    "Race": "Hobbit"
  },
  {
    "Name": "Sancho Proudfoot",
    "Url": "http://lotr.wikia.com//wiki/Sancho_Proudfoot",
    "Race": "Hobbit"
  },
  {
    "Name": "Olo Proudfoot",
    "Url": "http://lotr.wikia.com//wiki/Olo_Proudfoot",
    "Race": "Hobbit"
  },
  {
    "Name": "Nimloth (elf)",
    "Url": "http://lotr.wikia.com//wiki/Nimloth_(elf)",
    "Race": "Elf"
  },
  {
    "Name": "Saradoc Brandybuck",
    "Url": "http://lotr.wikia.com//wiki/Saradoc_Brandybuck",
    "Race": "Hobbit"
  },
  {
    "Name": "Gríma Wormtongue",
    "Url": "http://lotr.wikia.com//wiki/Gr%C3%ADma_Wormtongue",
    "Race": "Human"
  },
  {
    "Name": "Gollum",
    "Url": "http://lotr.wikia.com//wiki/Gollum",
    "Race": "Hobbit"
  },
  {
    "Name": "Elemmakil",
    "Url": "http://lotr.wikia.com//wiki/Elemmakil",
    "Race": "Elf"
  },
  {
    "Name": "Radagast",
    "Url": "http://lotr.wikia.com//wiki/Radagast",
    "Race": "Maiar"
  },
  {
    "Name": "Gandalf",
    "Url": "http://lotr.wikia.com//wiki/Gandalf",
    "Race": "Maiar"
  },
  {
    "Name": "Saruman",
    "Url": "http://lotr.wikia.com//wiki/Saruman",
    "Race": "Maiar"
  },
  {
    "Name": "Tilion",
    "Url": "http://lotr.wikia.com//wiki/Tilion",
    "Race": "Maiar"
  },
  {
    "Name": "Sauron",
    "Url": "http://lotr.wikia.com//wiki/Sauron",
    "Race": "Maiar"
  },
  {
    "Name": "Eönwë",
    "Url": "http://lotr.wikia.com//wiki/E%C3%B6nw%C3%AB",
    "Race": "Maiar"
  },
  {
    "Name": "Durin's Bane",
    "Url": "http://lotr.wikia.com//wiki/Durin%27s_Bane",
    "Race": "Maiar"
  },
  {
    "Name": "Alatar",
    "Url": "http://lotr.wikia.com//wiki/Alatar",
    "Race": "Maiar"
  },
  {
    "Name": "Pallando",
    "Url": "http://lotr.wikia.com//wiki/Pallando",
    "Race": "Maiar"
  },
  {
    "Name": "Arien",
    "Url": "http://lotr.wikia.com//wiki/Arien",
    "Race": "Maiar"
  },
  {
    "Name": "Uinen",
    "Url": "http://lotr.wikia.com//wiki/Uinen",
    "Race": "Maiar"
  },
  {
    "Name": "Moro Burrows",
    "Url": "http://lotr.wikia.com//wiki/Moro_Burrows",
    "Race": "Hobbit"
  },
  {
    "Name": "Mosco Burrows",
    "Url": "http://lotr.wikia.com//wiki/Mosco_Burrows",
    "Race": "Hobbit"
  },
  {
    "Name": "Myrtle Burrows",
    "Url": "http://lotr.wikia.com//wiki/Myrtle_Burrows",
    "Race": "Hobbit"
  },
  {
    "Name": "Thingol",
    "Url": "http://lotr.wikia.com//wiki/Thingol",
    "Race": "Elf"
  },
  {
    "Name": "Théodwyn",
    "Url": "http://lotr.wikia.com//wiki/Th%C3%A9odwyn",
    "Race": "Human"
  },
  {
    "Name": "Eärendil",
    "Url": "http://lotr.wikia.com//wiki/E%C3%A4rendil",
    "Race": "Human"
  },
  {
    "Name": "Harry Goatleaf",
    "Url": "http://lotr.wikia.com//wiki/Harry_Goatleaf",
    "Race": "Human"
  }
]
