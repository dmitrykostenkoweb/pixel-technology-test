set -e

__tests__/test-compat.sh "~2.5.0"
__tests__/test-compat.sh "~2.6.0"

